# **App Name**: CP Mart

## Core Features:

- Product Catalog Browsing: Allow users to browse and view products across various categories like Fashion, Electronics, and Mobile Accessories, with clear categorization for efficient discovery.
- Product Detail Pages: Provide dedicated pages for each product model, showcasing multiple images, detailed descriptions, pricing, and availability.
- Shopping Cart Management: Enable users to add desired products to a shopping cart, view their selected items, and adjust quantities before proceeding to checkout.
- Simplified Checkout & Payment Flow: Guide customers through a straightforward checkout process, culminating in a dedicated screen displaying the GPay QR Code for payment and clear instructions for order confirmation.
- Persistent Contact & Branding Header: A prominent header on every page displaying the brand's phone number '7907303634', a clickable WhatsApp button to '7907303634', and Instagram ID '@muhammedcp_', ensuring constant accessibility for customers.
- Product Content Generation Tool: An administrative tool to automatically generate basic, unique product descriptions and taglines for the large inventory based on product category, type, and specified keywords.
- Mobile-Responsive Design: Ensure the entire website layout and functionality adapt seamlessly across various devices, providing an optimal shopping experience on desktops, tablets, and smartphones.

## Style Guidelines:

- Primary color: A sophisticated Royal Blue (#2E78E5) to convey professionalism and trust.
- Background color: A very light, desaturated blue (#F2F6FC) to maintain a clean, expansive, and professional aesthetic.
- Accent color: A vibrant Aqua (#4DCAE3) for calls-to-action, highlights, and interactive elements, ensuring visual pop and user engagement.
- Headline and Body text font: 'Inter' (sans-serif) for its modern, clean, and highly readable characteristics, aligning with a professional e-commerce experience.
- Utilize simple, clear, and modern outline-style icons throughout the application, especially for navigation, shopping cart, search, and user profile, ensuring intuitive user interaction.
- Implement a clean, organized layout reminiscent of leading e-commerce platforms like Flipkart, featuring prominent product grids, a persistent top header for navigation and contact info, and clear category browsing options.
- Incorporate subtle hover effects on product cards and buttons, along with smooth transitions for page loads and modal dialogues, to enhance user interaction without distraction.