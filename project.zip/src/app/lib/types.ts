
export type ProductCategory = 'Fashion' | 'Electronics' | 'Mobile Accessories';

export interface Product {
  id: string;
  name: string;
  category: ProductCategory;
  subcategory: string;
  price: number;
  description: string;
  image: string;
  features?: string[];
  tagline?: string;
}

export interface CategoryGroup {
  name: ProductCategory;
  subcategories: string[];
}
