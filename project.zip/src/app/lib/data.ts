
import { Product, CategoryGroup } from './types';

export const CATEGORIES: CategoryGroup[] = [
  {
    name: 'Fashion',
    subcategories: ['Watches', 'Purses', 'Cooling glasses', 'Hand bands', 'Handbags', 'Side bags', 'School bags', 'Shoes', 'Chappals', 'Jerseys']
  },
  {
    name: 'Electronics',
    subcategories: ['Earpods', 'Earphones', 'Headsets', 'Mini-speakers', 'Chargers']
  },
  {
    name: 'Mobile Accessories',
    subcategories: ['Phone cases', 'Phone stands', 'Finger covers', 'OTG', 'SanDisk', 'Memory cards']
  }
];

const generateProducts = (): Product[] => {
  const products: Product[] = [];
  
  CATEGORIES.forEach(cat => {
    cat.subcategories.forEach(sub => {
      for (let i = 1; i <= 3; i++) {
        const id = `${cat.name.toLowerCase().replace(/\s+/g, '-')}-${sub.toLowerCase().replace(/\s+/g, '-')}-${i}`;
        let imageSeed = sub.toLowerCase().replace(/\s+/g, '');
        
        products.push({
          id,
          name: `CP ${sub} Model ${i}`,
          category: cat.name,
          subcategory: sub,
          price: Math.floor(Math.random() * 1000) + 499,
          description: `Premium quality ${sub} from CP Mart. This model features a sleek design, durable construction, and high-performance components suitable for everyday use. Perfect for style-conscious individuals who value reliability.`,
          image: `https://picsum.photos/seed/${imageSeed}${i}/600/400`,
          tagline: `Experience premium ${sub} with CP Mart.`
        });
      }
    });
  });
  
  return products;
};

export const PRODUCTS: Product[] = generateProducts();
