"use client"

import { use } from 'react';
import { PRODUCTS } from '@/app/lib/data';
import { useCart } from '@/context/CartContext';
import { Button } from '@/components/ui/button';
import { ShoppingCart, ArrowLeft, Heart, MessageCircle, Truck, ShieldCheck } from 'lucide-react';
import Image from 'next/image';
import Link from 'next/link';
import { toast } from '@/hooks/use-toast';
import { Badge } from '@/components/ui/badge';

export default function ProductPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const product = PRODUCTS.find(p => p.id === id);
  const { addToCart } = useCart();

  if (!product) {
    return (
      <div className="container mx-auto px-4 py-20 text-center">
        <h1 className="text-2xl font-bold mb-4">Product Not Found</h1>
        <Button asChild>
          <Link href="/">Back to Home</Link>
        </Button>
      </div>
    );
  }

  const handleAddToCart = () => {
    addToCart(product);
    toast({
      title: "Added to cart",
      description: `${product.name} has been added to your shopping cart.`,
    });
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <Link href="/" className="inline-flex items-center text-primary font-medium mb-8 hover:underline">
        <ArrowLeft size={18} className="mr-2" /> Back to Catalog
      </Link>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 bg-white p-6 sm:p-10 rounded-2xl shadow-sm border border-border">
        {/* Image Gallery */}
        <div className="space-y-4">
          <div className="relative aspect-square rounded-xl overflow-hidden bg-slate-50">
            <Image 
              src={product.image} 
              alt={product.name} 
              fill 
              className="object-contain"
              priority
              data-ai-hint="product detail image"
            />
          </div>
          <div className="grid grid-cols-4 gap-4">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="relative aspect-square rounded-lg overflow-hidden bg-slate-50 border border-slate-200">
                <Image 
                  src={`https://picsum.photos/seed/detail${i}${product.id}/200/200`}
                  alt={`Detail ${i}`}
                  fill
                  className="object-cover opacity-60 hover:opacity-100 transition-opacity cursor-pointer"
                />
              </div>
            ))}
          </div>
        </div>

        {/* Product Details */}
        <div className="flex flex-col">
          <div className="space-y-4">
            <div className="flex flex-wrap gap-2">
              <Badge variant="secondary" className="bg-primary/5 text-primary border-primary/10">
                {product.category}
              </Badge>
              <Badge variant="secondary" className="bg-accent/10 text-primary-foreground border-accent/20">
                {product.subcategory}
              </Badge>
            </div>
            
            <h1 className="text-3xl sm:text-4xl font-extrabold text-foreground">{product.name}</h1>
            <p className="text-xl font-medium text-accent italic">{product.tagline}</p>
            
            <div className="flex items-end gap-3 py-4">
              <span className="text-4xl font-extrabold text-primary">₹{product.price}</span>
              <span className="text-xl text-muted-foreground line-through pb-1">₹{product.price + 500}</span>
              <span className="text-green-600 font-bold mb-1 ml-2">Sale Ends Soon!</span>
            </div>

            <div className="border-y border-slate-100 py-6 space-y-4">
              <h3 className="font-bold text-lg">Product Description</h3>
              <p className="text-muted-foreground leading-relaxed">
                {product.description}
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-6">
              <Button 
                onClick={handleAddToCart}
                size="lg" 
                className="bg-accent hover:bg-accent/90 text-primary-foreground h-14 text-lg font-bold rounded-xl"
              >
                <ShoppingCart className="mr-2" /> Add to Cart
              </Button>
              <Button 
                variant="outline"
                size="lg" 
                className="h-14 text-lg font-bold rounded-xl border-primary text-primary hover:bg-primary/5"
                asChild
              >
                <Link href="/checkout">
                  Buy Now
                </Link>
              </Button>
            </div>

            <div className="pt-8 space-y-4">
              <div className="flex items-center gap-3 text-sm text-slate-700">
                <Truck className="text-primary" size={20} />
                <span>Delivered via <span className="font-bold">Professional Courier service</span></span>
              </div>
              <div className="flex items-center gap-3 text-sm text-slate-700">
                <ShieldCheck className="text-primary" size={20} />
                <span>Confirmed Payment via <span className="font-bold">WhatsApp Screenshot</span></span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Recommended Section */}
      <section className="mt-20">
        <h2 className="text-2xl font-bold mb-8">Related Products</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {PRODUCTS.filter(p => p.category === product.category && p.id !== product.id).slice(0, 4).map(p => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </section>
    </div>
  );
}
