
"use client"

import { useCart } from '@/context/CartContext';
import { Button } from '@/components/ui/button';
import { ShoppingBag, MessageCircle, ArrowLeft, CheckCircle2, ShieldCheck, Truck } from 'lucide-react';
import Image from 'next/image';
import Link from 'next/link';
import { useState } from 'react';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';

export default function CheckoutPage() {
  const { cart, totalPrice, clearCart } = useCart();
  const [step, setStep] = useState(1);
  
  const contactNumber = "7907303634";
  const whatsappUrl = `https://wa.me/${contactNumber}?text=${encodeURIComponent(
    `Hello CP Mart! I'd like to confirm my order for:\n\n${cart
      .map((item) => `- ${item.name} (Qty: ${item.quantity})`)
      .join('\n')}\n\nTotal: ₹${totalPrice}\n\nI have attached my GPay payment screenshot below.`
  )}`;

  if (cart.length === 0 && step === 1) {
    return (
      <div className="container mx-auto px-4 py-20 text-center">
        <div className="max-w-md mx-auto space-y-6">
          <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center text-slate-400 mx-auto">
            <ShoppingBag size={40} />
          </div>
          <h1 className="text-2xl font-bold">Your Cart is Empty</h1>
          <p className="text-muted-foreground">Add some items to your cart to proceed with checkout.</p>
          <Button asChild className="w-full h-12">
            <Link href="/">Browse Products</Link>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="max-w-4xl mx-auto">
        <div className="mb-10 text-center">
          <h1 className="text-3xl font-extrabold text-foreground">Secure Checkout</h1>
          <p className="text-muted-foreground mt-2">Finish your order and pay via GPay / UPI</p>
        </div>

        {step === 1 ? (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div className="bg-white p-8 rounded-2xl shadow-sm border border-border space-y-6">
              <h2 className="text-xl font-bold flex items-center gap-2">
                <ShoppingBag size={20} className="text-primary" />
                Order Summary
              </h2>
              <Separator />
              <div className="space-y-4 max-h-[400px] overflow-y-auto pr-2">
                {cart.map((item) => (
                  <div key={item.id} className="flex gap-4">
                    <div className="relative h-16 w-16 rounded-md overflow-hidden bg-slate-50 shrink-0 border">
                      <Image src={item.image} alt={item.name} fill className="object-cover" />
                    </div>
                    <div className="flex-grow">
                      <h4 className="font-medium text-sm">{item.name}</h4>
                      <p className="text-xs text-muted-foreground">Qty: {item.quantity}</p>
                      <p className="text-sm font-bold text-primary">₹{item.price * item.quantity}</p>
                    </div>
                  </div>
                ))}
              </div>
              <Separator />
              <div className="space-y-2 pt-2">
                <div className="flex justify-between text-sm">
                  <span>Subtotal</span>
                  <span>₹{totalPrice}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Shipping</span>
                  <span className="text-green-600 font-medium">FREE</span>
                </div>
                <div className="flex justify-between items-center text-xl font-extrabold pt-4 border-t">
                  <span>Total Amount</span>
                  <span className="text-primary">₹{totalPrice}</span>
                </div>
              </div>
            </div>

            <div className="space-y-8">
              <div className="bg-white p-8 rounded-2xl shadow-sm border border-border">
                <h2 className="text-xl font-bold mb-6">Delivery Method</h2>
                <div className="space-y-4">
                  <div className="p-4 bg-primary/5 rounded-xl border border-primary/10">
                    <div className="flex items-center gap-3 mb-2">
                      <Truck className="text-primary" size={20} />
                      <p className="text-sm font-bold">Professional Courier</p>
                    </div>
                    <p className="text-xs text-muted-foreground">Tracking details will be shared on WhatsApp once payment is verified.</p>
                  </div>
                  <Button onClick={() => setStep(2)} className="w-full h-14 text-lg font-bold bg-primary hover:bg-primary/90 rounded-xl shadow-lg">
                    Proceed to Payment
                  </Button>
                </div>
              </div>

              <div className="p-4 rounded-xl border border-dashed border-accent flex items-start gap-4 bg-accent/5">
                <ShieldCheck className="text-primary shrink-0" size={20} />
                <div>
                  <h4 className="font-bold text-sm">Verified Payments</h4>
                  <p className="text-xs text-muted-foreground">Secure payment verification via WhatsApp screenshot for your peace of mind.</p>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="max-w-lg mx-auto bg-white p-8 sm:p-12 rounded-2xl shadow-2xl border-2 border-primary/20 text-center space-y-8">
            <div className="space-y-2">
              <Badge variant="outline" className="mb-2 text-primary border-primary">Final Step</Badge>
              <h2 className="text-3xl font-extrabold text-foreground">Pay ₹{totalPrice}</h2>
              <p className="text-muted-foreground">Scan the QR code to pay via any UPI app (GPay, PhonePe, Paytm)</p>
            </div>

            <div className="relative aspect-square max-w-[280px] mx-auto bg-slate-50 p-6 border-2 border-slate-100 rounded-3xl shadow-inner">
              <Image 
                src="https://picsum.photos/seed/qr-code/400/400"
                alt="Payment QR Code"
                fill
                className="object-contain p-2"
                data-ai-hint="payment qr"
              />
            </div>

            <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200 text-left space-y-4">
              <h3 className="font-bold text-primary flex items-center gap-2">
                <CheckCircle2 size={18} />
                How to confirm?
              </h3>
              <ol className="text-sm space-y-3 list-decimal pl-4 text-slate-700">
                <li>Complete the payment of <span className="font-bold">₹{totalPrice}</span> using your UPI app.</li>
                <li>Take a <span className="font-bold">screenshot</span> of the success screen.</li>
                <li>Click the button below to send the screenshot on WhatsApp.</li>
              </ol>
            </div>

            <div className="flex flex-col gap-3">
              <Button asChild size="lg" className="h-16 text-lg font-extrabold bg-green-600 hover:bg-green-700 rounded-xl shadow-xl transition-all active:scale-95">
                <a href={whatsappUrl} target="_blank" rel="noopener noreferrer">
                  <MessageCircle className="mr-2" /> Confirm on WhatsApp
                </a>
              </Button>
              <Button variant="ghost" onClick={() => setStep(1)} className="text-muted-foreground hover:text-primary">
                <ArrowLeft size={16} className="mr-2" /> Back to Summary
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
