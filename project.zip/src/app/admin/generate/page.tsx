"use client"

import { useState } from 'react';
import { generateProductDescriptions, GenerateProductDescriptionsOutput } from '@/ai/flows/generate-product-descriptions';
import { CATEGORIES } from '@/app/lib/data';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Loader2, Sparkles, Copy, Check } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

export default function AdminGeneratePage() {
  const [category, setCategory] = useState<string>('');
  const [productType, setProductType] = useState<string>('');
  const [keywords, setKeywords] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<GenerateProductDescriptionsOutput | null>(null);
  const [copied, setCopied] = useState(false);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!category || !productType || !keywords) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Please fill all fields to generate content.",
      });
      return;
    }

    setIsLoading(true);
    setResult(null);

    try {
      const output = await generateProductDescriptions({
        category,
        productType,
        keywords: keywords.split(',').map(k => k.trim()),
      });
      setResult(output);
      toast({
        title: "Success",
        description: "Product content generated successfully!",
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Generation Failed",
        description: "There was an error generating the content. Please try again.",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    toast({
      title: "Copied",
      description: "Content copied to clipboard.",
    });
  };

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="max-w-4xl mx-auto space-y-8">
        <div className="text-center">
          <h1 className="text-3xl font-extrabold flex items-center justify-center gap-3">
            <Sparkles className="text-accent" />
            AI Content Generator
          </h1>
          <p className="text-muted-foreground mt-2">Generate professional descriptions and taglines for your CP Mart inventory.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Input Form */}
          <Card className="border-2 border-primary/10 shadow-lg">
            <CardHeader>
              <CardTitle>Product Details</CardTitle>
              <CardDescription>Enter product information to guide the AI.</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleGenerate} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="category">Category</Label>
                  <Select onValueChange={setCategory} value={category}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select Category" />
                    </SelectTrigger>
                    <SelectContent>
                      {CATEGORIES.map((cat) => (
                        <SelectItem key={cat.name} value={cat.name}>
                          {cat.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="productType">Specific Product Type</Label>
                  <Input 
                    id="productType"
                    placeholder="e.g. Luxury Watch, Smart Earbuds" 
                    value={productType}
                    onChange={(e) => setProductType(e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="keywords">Keywords (comma separated)</Label>
                  <Textarea 
                    id="keywords"
                    placeholder="e.g. waterproof, stylish, bluetooth 5.0, durable" 
                    className="min-h-[100px]"
                    value={keywords}
                    onChange={(e) => setKeywords(e.target.value)}
                  />
                </div>

                <Button 
                  type="submit" 
                  className="w-full bg-primary hover:bg-primary/90 h-12 font-bold"
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Generating...
                    </>
                  ) : (
                    <>
                      <Sparkles className="mr-2 h-4 w-4" />
                      Generate Marketing Content
                    </>
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Result Display */}
          <div className="space-y-6">
            {!result && !isLoading && (
              <div className="h-full flex flex-col items-center justify-center text-center p-8 border-2 border-dashed rounded-2xl bg-slate-50 opacity-60">
                <Sparkles size={48} className="text-slate-300 mb-4" />
                <h3 className="text-lg font-medium">Ready to Generate</h3>
                <p className="text-sm text-muted-foreground">Fill in the form to generate AI marketing copy.</p>
              </div>
            )}

            {isLoading && (
              <div className="h-full flex flex-col items-center justify-center space-y-4 p-8 border-2 border-dashed rounded-2xl bg-slate-50">
                <Loader2 size={48} className="text-primary animate-spin" />
                <p className="font-medium">AI is crafting the perfect copy...</p>
              </div>
            )}

            {result && (
              <Card className="border-2 border-accent/20 shadow-xl overflow-hidden animate-in fade-in slide-in-from-bottom-4">
                <CardHeader className="bg-accent/5">
                  <CardTitle className="text-primary">Generated Content</CardTitle>
                </CardHeader>
                <CardContent className="p-6 space-y-6">
                  <div className="space-y-2 relative">
                    <div className="flex justify-between items-center">
                      <Label className="text-xs uppercase tracking-wider text-muted-foreground">Product Tagline</Label>
                      <button onClick={() => copyToClipboard(result.tagline)} className="text-slate-400 hover:text-primary transition-colors">
                        {copied ? <Check size={16} /> : <Copy size={16} />}
                      </button>
                    </div>
                    <div className="p-4 bg-slate-50 rounded-lg text-lg font-bold text-slate-800">
                      "{result.tagline}"
                    </div>
                  </div>

                  <div className="space-y-2 relative">
                    <div className="flex justify-between items-center">
                      <Label className="text-xs uppercase tracking-wider text-muted-foreground">Product Description</Label>
                      <button onClick={() => copyToClipboard(result.description)} className="text-slate-400 hover:text-primary transition-colors">
                        {copied ? <Check size={16} /> : <Copy size={16} />}
                      </button>
                    </div>
                    <div className="p-4 bg-slate-50 rounded-lg text-sm leading-relaxed text-slate-700 min-h-[150px]">
                      {result.description}
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="bg-slate-50 p-4">
                  <p className="text-[10px] text-muted-foreground italic">
                    AI-generated content for CP Mart Marketing. Please review before publishing.
                  </p>
                </CardFooter>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
