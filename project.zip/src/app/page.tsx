
"use client"

import { CATEGORIES, PRODUCTS } from '@/app/lib/data';
import ProductCard from '@/components/product/ProductCard';
import { Button } from '@/components/ui/button';
import { ArrowRight, Truck, ShieldCheck, Headphones, Zap, ShoppingBag } from 'lucide-react';
import Image from 'next/image';
import Link from 'next/link';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';

export default function Home() {
  const featuredProducts = PRODUCTS.slice(0, 8);

  return (
    <div className="space-y-12 pb-12">
      <section className="relative h-[400px] sm:h-[600px] w-full overflow-hidden bg-slate-900">
        <Image 
          src="https://picsum.photos/seed/mall/1200/600"
          alt="CP Mart Banner"
          fill
          className="object-cover opacity-60"
          priority
          data-ai-hint="luxury mall"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/70 to-transparent" />
        <div className="absolute inset-0 flex items-center">
          <div className="container mx-auto px-4">
            <div className="max-w-2xl text-white space-y-6">
              <Badge className="bg-accent text-primary-foreground font-bold px-4 py-1">New Arrivals 2024</Badge>
              <h1 className="text-5xl sm:text-7xl font-extrabold leading-tight tracking-tighter">
                Premium Store <br />
                <span className="text-accent underline underline-offset-8">CP Mart</span>
              </h1>
              <p className="text-xl sm:text-2xl opacity-90 max-w-lg font-light leading-relaxed">
                Shop the latest in Fashion, Electronics, and Mobile Accessories. Quality you can trust at prices you'll love.
              </p>
              <Button size="lg" className="bg-primary hover:bg-primary/90 text-white font-bold rounded-full px-10 py-7 h-auto text-xl shadow-2xl transition-transform hover:scale-105" asChild>
                <Link href="#featured">Start Shopping <ArrowRight className="ml-2" /></Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      <section className="container mx-auto px-4 -mt-16 relative z-10">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 p-8 bg-white rounded-3xl shadow-xl border border-slate-100">
          {[
            { icon: Truck, label: "Fast Shipping", sub: "Professional Courier" },
            { icon: ShieldCheck, label: "Secure Payment", sub: "Verify on WhatsApp" },
            { icon: Headphones, label: "Best Support", sub: "24/7 Availability" },
            { icon: Zap, label: "Top Quality", sub: "Handpicked Selection" }
          ].map((item, i) => (
            <div key={i} className="flex flex-col items-center text-center space-y-2">
              <div className="p-3 bg-primary/5 rounded-2xl">
                <item.icon size={28} className="text-primary" />
              </div>
              <div>
                <h3 className="font-bold text-base">{item.label}</h3>
                <p className="text-xs text-muted-foreground">{item.sub}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="container mx-auto px-4 pt-12" id="featured">
        <div className="flex flex-col md:flex-row justify-between items-end mb-10 gap-4">
          <div className="space-y-2">
            <h2 className="text-4xl font-extrabold tracking-tight text-foreground">Featured Collections</h2>
            <p className="text-muted-foreground text-lg">Curated styles and latest tech gadgets just for you.</p>
          </div>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {featuredProducts.map((p) => <ProductCard key={p.id} product={p} />)}
        </div>
      </section>

      <section className="container mx-auto px-4 py-12">
        <div className="bg-primary rounded-[3rem] p-10 sm:p-20 text-center text-white relative overflow-hidden shadow-2xl">
          <div className="relative z-10 space-y-8 max-w-3xl mx-auto">
            <ShoppingBag size={64} className="mx-auto text-accent animate-bounce" />
            <h2 className="text-4xl sm:text-6xl font-extrabold leading-none">Ready to upgrade?</h2>
            <p className="text-xl opacity-80 font-light">
              Join thousands of happy customers shopping at CP Mart today. Quick checkout via WhatsApp for personalized service.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Button size="lg" className="bg-white text-primary hover:bg-slate-100 font-bold rounded-full px-10 py-7 h-auto text-xl shadow-xl" asChild>
                <Link href="#featured">View Products</Link>
              </Button>
              <Button size="lg" variant="outline" className="text-white border-white hover:bg-white hover:text-primary font-bold rounded-full px-10 py-7 h-auto text-xl" asChild>
                <a href="https://wa.me/7907303634" target="_blank" rel="noopener noreferrer">Contact Support</a>
              </Button>
            </div>
          </div>
          <div className="absolute top-0 right-0 w-96 h-96 bg-accent/20 rounded-full -translate-y-1/2 translate-x-1/2 blur-[100px]" />
          <div className="absolute bottom-0 left-0 w-96 h-96 bg-white/10 rounded-full translate-y-1/2 -translate-x-1/2 blur-[100px]" />
        </div>
      </section>
    </div>
  );
}
