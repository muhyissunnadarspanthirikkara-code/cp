
"use client"

import Image from 'next/image';
import Link from 'next/link';
import { ShoppingCart, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Product } from '@/app/lib/types';
import { useCart } from '@/context/CartContext';
import { toast } from '@/hooks/use-toast';
import { Badge } from '@/components/ui/badge';

interface ProductCardProps {
  product: Product;
}

export default function ProductCard({ product }: ProductCardProps) {
  const { addToCart } = useCart();

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    addToCart(product);
    toast({
      title: "Added to cart",
      description: `${product.name} has been added to your shopping cart.`,
    });
  };

  return (
    <Link href={`/product/${product.id}`} className="group block bg-white rounded-lg overflow-hidden border border-border shadow-sm hover:shadow-md transition-all duration-300">
      <div className="relative aspect-[4/3] bg-slate-50 overflow-hidden">
        <Image 
          src={product.image} 
          alt={product.name}
          fill
          className="object-cover group-hover:scale-105 transition-transform duration-500"
          sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 25vw"
          data-ai-hint="product image"
        />
        <Badge className="absolute top-2 left-2 bg-accent text-primary-foreground font-semibold">
          Under ₹2000
        </Badge>
      </div>
      <div className="p-4">
        <div className="text-xs text-muted-foreground uppercase tracking-wider mb-1">
          {product.category} • {product.subcategory}
        </div>
        <h3 className="font-semibold text-lg text-foreground line-clamp-1 mb-2 group-hover:text-primary transition-colors">
          {product.name}
        </h3>
        <div className="flex items-center justify-between mt-4">
          <div>
            <span className="text-xl font-bold text-primary">₹{product.price}</span>
            <span className="ml-2 text-sm text-muted-foreground line-through">₹{product.price + 500}</span>
          </div>
          <Button 
            size="sm" 
            className="bg-accent hover:bg-accent/90 text-primary-foreground rounded-full h-9 w-9 p-0 flex items-center justify-center shadow-sm"
            onClick={handleAddToCart}
          >
            <Plus size={18} />
          </Button>
        </div>
      </div>
    </Link>
  );
}
