
"use client"

import Link from 'next/link';
import { Phone, MessageCircle, Instagram, ShoppingCart, Search, Menu } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useCart } from '@/context/CartContext';
import { Input } from '@/components/ui/input';
import { useState } from 'react';
import CartDrawer from '@/components/cart/CartDrawer';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';

export default function Header() {
  const { itemCount } = useCart();
  const [isCartOpen, setIsCartOpen] = useState(false);

  const contactNumber = "7907303634";
  const whatsappUrl = `https://wa.me/${contactNumber}`;
  const instagramUrl = "https://instagram.com/muhammedcp_";

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-primary text-white shadow-md">
      <div className="bg-primary-foreground/10 py-1.5 px-4 text-xs sm:text-sm border-b border-white/10">
        <div className="container mx-auto flex flex-wrap justify-between items-center gap-4">
          <div className="flex items-center gap-4">
            <a href={`tel:${contactNumber}`} className="flex items-center gap-1.5 hover:text-accent transition-colors">
              <Phone size={14} /> {contactNumber}
            </a>
            <a href={whatsappUrl} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1.5 hover:text-accent transition-colors">
              <MessageCircle size={14} /> WhatsApp
            </a>
          </div>
          <a href={instagramUrl} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1.5 hover:text-accent transition-colors">
            <Instagram size={14} /> @muhammedcp_
          </a>
        </div>
      </div>

      <div className="container mx-auto py-3 px-4 flex items-center justify-between gap-4">
        <Link href="/" className="text-xl sm:text-2xl font-bold tracking-tight shrink-0">
          CP MART
        </Link>

        <div className="hidden md:flex relative flex-1 max-w-xl">
          <Input 
            placeholder="Search for premium products..." 
            className="w-full bg-white text-foreground pl-4 pr-10 h-10 border-none focus-visible:ring-offset-0 focus-visible:ring-accent"
          />
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground" size={18} />
        </div>

        <div className="flex items-center gap-3 sm:gap-6">
          <Link href="/admin/generate" className="hidden lg:block text-sm font-medium hover:text-accent">
            AI Tools
          </Link>
          
          <Button 
            variant="ghost" 
            className="relative p-2 h-auto text-white hover:bg-white/10 hover:text-white"
            onClick={() => setIsCartOpen(true)}
          >
            <ShoppingCart size={24} />
            {itemCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-accent text-primary text-[10px] font-bold h-5 w-5 rounded-full flex items-center justify-center">
                {itemCount}
              </span>
            )}
            <span className="hidden sm:inline ml-2 font-medium">Cart</span>
          </Button>

          <div className="md:hidden">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="text-white">
                  <Menu size={24} />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                <DropdownMenuItem asChild>
                  <Link href="/">Home</Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/admin/generate">AI Generator</Link>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>

      <CartDrawer open={isCartOpen} onOpenChange={setIsCartOpen} />
    </header>
  );
}
