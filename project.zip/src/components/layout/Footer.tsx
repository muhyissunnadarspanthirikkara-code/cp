import Link from 'next/link';
import { Phone, MessageCircle, Instagram, Truck, ShieldCheck, Clock } from 'lucide-react';

export default function Footer() {
  const contactNumber = "7907303634";
  
  return (
    <footer className="bg-slate-900 text-slate-300 pt-12 pb-6">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10 mb-12">
          {/* Brand Info */}
          <div className="col-span-1 md:col-span-1">
            <h2 className="text-2xl font-bold text-white mb-4">CP MART</h2>
            <p className="text-sm leading-relaxed mb-6">
              Your one-stop destination for premium fashion, electronics, and mobile accessories. Quality products at affordable prices.
            </p>
            <div className="flex gap-4">
              <a href={`https://wa.me/${contactNumber}`} className="hover:text-accent transition-colors"><MessageCircle size={20} /></a>
              <a href="https://instagram.com/muhammedcp_" className="hover:text-accent transition-colors"><Instagram size={20} /></a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-4">Categories</h3>
            <ul className="space-y-2 text-sm">
              <li><Link href="/" className="hover:text-accent">Fashion</Link></li>
              <li><Link href="/" className="hover:text-accent">Electronics</Link></li>
              <li><Link href="/" className="hover:text-accent">Mobile Accessories</Link></li>
              <li><Link href="/admin/generate" className="hover:text-accent">Admin Generation</Link></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-4">Contact Us</h3>
            <ul className="space-y-3 text-sm">
              <li className="flex items-center gap-3">
                <Phone size={16} className="text-accent" />
                <span>+91 {contactNumber}</span>
              </li>
              <li className="flex items-center gap-3">
                <MessageCircle size={16} className="text-accent" />
                <span>WhatsApp: {contactNumber}</span>
              </li>
              <li className="flex items-center gap-3">
                <Instagram size={16} className="text-accent" />
                <span>@muhammedcp_</span>
              </li>
            </ul>
          </div>

          {/* Policy Info */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-4">Shipping Policy</h3>
            <div className="bg-white/5 rounded-lg p-4 space-y-3">
              <div className="flex items-start gap-3 text-xs">
                <Truck size={18} className="text-accent shrink-0" />
                <p>Products will be delivered via <span className="text-white font-medium">Professional Courier service</span>.</p>
              </div>
              <div className="flex items-start gap-3 text-xs">
                <ShieldCheck size={18} className="text-accent shrink-0" />
                <p>Safe and secure payment confirmation via WhatsApp.</p>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-white/10 pt-6 flex flex-col md:flex-row justify-between items-center gap-4 text-xs">
          <p>© {new Date().getFullYear()} CP Mart. All rights reserved.</p>
          <div className="flex gap-6">
            <Link href="#" className="hover:text-white">Privacy Policy</Link>
            <Link href="#" className="hover:text-white">Terms of Service</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
