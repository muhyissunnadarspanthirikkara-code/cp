'use server';
/**
 * @fileOverview A Genkit flow for generating product descriptions and taglines.
 *
 * - generateProductDescriptions - A function that handles the generation of product descriptions and taglines.
 * - GenerateProductDescriptionsInput - The input type for the generateProductDescriptions function.
 * - GenerateProductDescriptionsOutput - The return type for the generateProductDescriptions function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GenerateProductDescriptionsInputSchema = z.object({
  category: z.string().describe('The product category (e.g., Fashion, Electronics).'),
  productType: z.string().describe('The specific type of product (e.g., Watches, Earpods).'),
  keywords: z.array(z.string()).describe('A list of keywords describing the product.'),
});
export type GenerateProductDescriptionsInput = z.infer<typeof GenerateProductDescriptionsInputSchema>;

const GenerateProductDescriptionsOutputSchema = z.object({
  description: z.string().describe('A basic, unique product description.'),
  tagline: z.string().describe('A catchy product tagline.'),
});
export type GenerateProductDescriptionsOutput = z.infer<typeof GenerateProductDescriptionsOutputSchema>;

export async function generateProductDescriptions(input: GenerateProductDescriptionsInput): Promise<GenerateProductDescriptionsOutput> {
  return generateProductDescriptionsFlow(input);
}

const productDescriptionPrompt = ai.definePrompt({
  name: 'productDescriptionPrompt',
  input: {schema: GenerateProductDescriptionsInputSchema},
  output: {schema: GenerateProductDescriptionsOutputSchema},
  prompt: `You are a professional marketing copywriter for the e-commerce brand 'CP Mart'.
Your task is to create a concise, unique product description and a catchy tagline for a new product.

Product Category: {{{category}}}
Product Type: {{{productType}}}
Product Keywords: {{#each keywords}}{{{this}}}{{#unless @last}}, {{/unless}}{{/each}}

Please ensure the description is basic, yet highlights key features or benefits related to the keywords, and the tagline is short, memorable, and suitable for an e-commerce website. Make the content engaging and persuasive for customers.`,
});

const generateProductDescriptionsFlow = ai.defineFlow(
  {
    name: 'generateProductDescriptionsFlow',
    inputSchema: GenerateProductDescriptionsInputSchema,
    outputSchema: GenerateProductDescriptionsOutputSchema,
  },
  async (input) => {
    const {output} = await productDescriptionPrompt(input);
    return output!;
  }
);
